#define CLOCKOUT 14//15
#define ENABLE_PIN 32

#define SCLK 26
#define MISO 33
#define MOSI 25
#define chipCS 27

#define btn1 4
#define btn2 13
